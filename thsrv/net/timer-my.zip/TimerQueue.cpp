/****************************************************************************
* @File:	定时器队列封装类
* @Date:	2020-2-26
* @Author:	T.H.
* @Note:	功能说明：
* @Version:	V0.1
****************************************************************************/

//----------------------Include Header----------------------------
//related current file header
//c library header
//c++ library header
//related others' project file header
#include "thsrv/net/TimerQueue.h"
#include "thsrv/net/EventLoop.h"

namespace thsrv
{

namespace net
{

/// START CLASS
TimerQueue::TimerQueue(EventLoop* loop):
loop_(loop)
{}
void TimerQueue::addTimer()
{

}
/// END CLASS

} //END NET NAMESPACE
	
}  //END THSRV NAMESPACE


