/****************************************************************************
* @File:	定时器队列封装类
* @Date:	2020-2-26
* @Author:	T.H.
* @Note:	功能说明：

* @Version:	V0.1
****************************************************************************/
#pragma once

#ifndef THSRV_NET_TIMERQUEUE_H
#define THSRV_NET_TIMERQUEUE_H

//----------------------Include Header----------------------------
//related current file header
//c library header
//c++ library header
//related others' project file header
#include "thsrv/base/TimeStamp.h"
#include "thsrv/net/Timer.h"

#include <functional>
#include <memory>
#include <vector>

namespace thsrv
{
	
namespace net
{
	
class EventLoop;

class TimerQueue
{
public:
    typedef std::function<void()>TimerCallbck;
    typedef std::unique_ptr<Timer> TimerPtr;
    typedef std::vector<TimerPtr> TimerList;
public:
    TimerQueue(EventLoop* loop);
    void addTimer(const TimeStamp& when, const TimerCallback& cb, double interval);
    void cancelTimer(const TimerPtr& timer);
private:
    EventLoop* loop_;
    TimerList activeTimer_;
};  //END TimerQueue CLASS
	
}  //END NET NAMESPACE
	
}  //END THSRV NAMESPACE


#endif   //END THSRV_NET_TIMERQUEUE_H

